import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function AccionCard({ accion }) {
  return (
    <View style={styles.card}>
      <Image source={{ uri: accion.imagen }} style={styles.image} />
      <Text style={styles.title}>{accion.nombre}</Text>
      <Text>{accion.descripcion}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card:
   { 
    backgroundColor: '#e0f7e9',
     padding: 10,
      marginVertical: 10,
      borderRadius: 10, 
      alignItems: 'center',
       width: 300 
    },
  image: 
  {
     width: 280, 
     height: 150,
      borderRadius: 10
     },
  title: 
  { fontWeight: 'bold',
     fontSize: 18,
      marginVertical: 5 
    },
});
