import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import HomeScreen from '../src/HomeScreen';
import AccionesVerdesScreen from '../src/AccionesVerdesScreen';
import MisActividadesScreen from '../src/MisActividadesScreen';

const Drawer = createDrawerNavigator();

export default function DrawerNavigator() {
  return (
    <Drawer.Navigator initialRouteName="Inicio">
      <Drawer.Screen name="Inicio" component={HomeScreen} />
      <Drawer.Screen name="Acciones Verdes" component={AccionesVerdesScreen} />
      <Drawer.Screen name="Mis Actividades" component={MisActividadesScreen} />
    </Drawer.Navigator>
  );
}

