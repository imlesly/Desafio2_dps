import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bienvenido a EcoVida_App </Text>

      <TouchableOpacity onPress={() => navigation.navigate('Acciones Verdes')}>
        <Image
          source={{ uri: 'https://cdn.pixabay.com/photo/2017/06/16/10/05/tree-2405740_1280.jpg' }}
          style={styles.image}
        />
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Mis Actividades')}>
        <Image
          source={{ uri: 'https://cdn.pixabay.com/photo/2016/11/29/09/32/plant-1868107_1280.jpg' }}
          style={styles.image}
        />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:
   { flex: 1,
    alignItems: 'center',
     justifyContent: 'center',
      padding: 20 
    },
  title: 
  { fontSize: 24,
     fontWeight: 'bold', 
     marginBottom: 20 
    },
  image: 
  { width: 300, 
    height: 200, 
    borderRadius: 15, 
    marginVertical: 10 
},
});
