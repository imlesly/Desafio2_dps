import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import AccionCard from '../components/AccionCard';

const acciones = [
  { id: '1', nombre: 'Plantar Árboles', descripcion: 'Ayuda a capturar CO2.', imagen: 'https://media.admagazine.com/photos/618a70bfbe961b98e9f09fba/16:9/w_2560%2Cc_limit/28669.jpg' },
  { id: '2', nombre: 'Reciclar', descripcion: 'Reduce el consumo de recursos.', imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBjvWNLONIsU8_m5MIdw_M-EX3Gp1_uAz79A&s' },
  { id: '3', nombre: 'Usar Bicicleta', descripcion: 'Disminuye emisiones.', imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRMv-6_94Noj-b5KCcHyzhEFPtdrzVxKeCYNg&s' },
  { id: '4', nombre: 'Ahorrar Energía', descripcion: 'Cuida los recursos naturales.', imagen: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRk2reEsROzvCIYUr9mizoHhUyHcbNE5bmUQg&s' },
];

export default function AccionesVerdesScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {acciones.map((accion) => (
        <AccionCard key={accion.id} accion={accion} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: 
  { 
    padding: 10,
    alignItems: 'center' 
},
});
