import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function ActividadItem({ item, eliminarActividad }) {
  return (
    <View style={styles.item}>
      <Text style={styles.title}>{item.nombre}</Text>
      <Text>{item.fecha} - {item.lugar}</Text>
      <Button title="Eliminar" color="red" onPress={() => eliminarActividad(item.id)} />
    </View>
  );
}

const styles = StyleSheet.create({
  item: 
  { backgroundColor: '#fff',
     padding: 15, 
     marginVertical: 8, 
     borderRadius: 8, 
     elevation: 2 },
  title: 
  { fontWeight: 'bold', 
    fontSize: 16 
},
});
