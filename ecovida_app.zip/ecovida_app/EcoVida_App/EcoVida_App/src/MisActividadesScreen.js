import React, { useState, useEffect } from 'react';
import { View, TextInput, Button, FlatList, StyleSheet, Text, TouchableOpacity } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ActividadItem from '../components/ActividadItem';

export default function MisActividadesScreen() {
  const [nombre, setNombre] = useState('');
  const [fecha, setFecha] = useState('');
  const [lugar, setLugar] = useState('');
  const [actividades, setActividades] = useState([]);

  useEffect(() => {
    cargarActividades();
  }, []);

  const guardarActividad = async () => {
    if (nombre && fecha && lugar) {
      const nuevaActividad = { id: Date.now().toString(), nombre, fecha, lugar };
      const nuevasActividades = [...actividades, nuevaActividad];
      setActividades(nuevasActividades);
      await AsyncStorage.setItem('actividades', JSON.stringify(nuevasActividades));
      setNombre('');
      setFecha('');
      setLugar('');
    }
  };

  const cargarActividades = async () => {
    const data = await AsyncStorage.getItem('actividades');
    if (data) {
      setActividades(JSON.parse(data));
    }
  };

  const eliminarActividad = async (id) => {
    const nuevas = actividades.filter((a) => a.id !== id);
    setActividades(nuevas);
    await AsyncStorage.setItem('actividades', JSON.stringify(nuevas));
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Nombre" value={nombre} onChangeText={setNombre} style={styles.input} />
      <TextInput placeholder="Fecha" value={fecha} onChangeText={setFecha} style={styles.input} />
      <TextInput placeholder="Lugar" value={lugar} onChangeText={setLugar} style={styles.input} />
      <Button title="Agregar Actividad" onPress={guardarActividad} />

      <FlatList
        data={actividades}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ActividadItem item={item} eliminarActividad={eliminarActividad} />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  input: { borderWidth: 1, marginBottom: 10, padding: 8, borderRadius: 5 },
});
