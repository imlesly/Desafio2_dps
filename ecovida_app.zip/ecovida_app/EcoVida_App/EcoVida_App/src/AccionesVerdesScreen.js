import React from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import AccionCard from '../components/AccionCard';

const acciones = [
  { id: '1', nombre: 'Plantar Árboles', descripcion: 'Ayuda a capturar CO2.', imagen: 'https://cdn.pixabay.com/photo/2016/11/29/09/32/plant-1868107_1280.jpg' },
  { id: '2', nombre: 'Reciclar', descripcion: 'Reduce el consumo de recursos.', imagen: 'https://cdn.pixabay.com/photo/2016/11/21/15/46/recycle-1845356_1280.jpg' },
  { id: '3', nombre: 'Usar Bicicleta', descripcion: 'Disminuye emisiones.', imagen: 'https://cdn.pixabay.com/photo/2016/03/27/21/16/bicycle-1284975_1280.jpg' },
  { id: '4', nombre: 'Ahorrar Energía', descripcion: 'Cuida los recursos naturales.', imagen: 'https://cdn.pixabay.com/photo/2017/03/02/08/54/light-bulb-2111560_1280.jpg' },
];

export default function AccionesVerdesScreen() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {acciones.map((accion) => (
        <AccionCard key={accion.id} accion={accion} />
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: 
  { 
    padding: 10,
    alignItems: 'center' 
},
});
